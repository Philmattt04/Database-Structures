Python 3.12.3 (v3.12.3:f6650f9ad7, Apr  9 2024, 08:18:47) [Clang 13.0.0 (clang-1300.0.29.30)] on darwin
Type "help", "copyright", "credits" or "license()" for more information.
import datetime
import mysql.connector

cnx = mysql.connector.connect(user='root', password='SQL_Learner2024', host='localhost', database='AmazonWebPage')

cursor = cnx.cursor

try:
    '''
    Query 1: Show the details of a customer with a specific email address
    '''
    email = 'jerrycurls123@gmail.com'
    query = "SELECT * FROM Customer WHERE email = %s;"
    cursor.execute(query, (email,))
    print("Query 1 Result:")
    for row in cursor:
        print(row)

    '''
    Query 2: Show all items in a specific shopping cart
    '''
    cart_id = 202
    query = "SELECT * FROM Item WHERE cart_id = %s;"
    cursor.execute(query,(cart_id))
    print("Query 2 Result:")
    for row in cursor
    
SyntaxError: expected ':'
try:
    '''
    Query 1: Show the details of a customer with a specific email address
    '''
    email = 'jerrycurls123@gmail.com'
    query = "SELECT * FROM Customer WHERE email = %s;"
    cursor.execute(query, (email,))
    print("Query 1 Result:")
    for row in cursor:
        print(row)

    '''
    Query 2: Show all items in a specific shopping cart
    '''
    cart_id = 202
    query = "SELECT * FROM Item WHERE cart_id = %s;"
    cursor.execute(query,(cart_id))
    print("Query 2 Result:")
    for row in cursor:
        print(row)

    '''
    Query 3: Show the names of customers and the names of products they have in their shopping carts
    '''
    query = """
    SELECT c.name AS customer_name, p.name AS product_name
    FROM ShoppingCart sc
    JOIN Customer c ON sc.customer_id = c.customer_id
    JOIN Item i ON sc.cart_id = i.cart_id
    JOIN Product p ON i.product_id = p.product_id;
    """
    cursor.execute(query)
    print("Query 3 Result:")
    for row in cursor:
        print(row)

    '''
    Query 4: Show the names, prices, and quantities of products in a specific shopping cart
    '''
    cart_id = 202
    query = """
    SELECT p.name AS product_name, p.price, i.quantity
    FROM Item i
    JOIN Product p ON i.product_id = p.product_id
    WHERE i.cart_id = %s;
    """
    cursor.execute(query, (cart_id,))
    print("Query 4 Result:")
    for row in cursor:
        print(row)

    '''
    Query 5: Update the address of a customer with a specific customer ID
    '''
    new_address = '456 Elm St'
    customer_id = 2
    query = "UPDATE Customer SET address = %s WHERE customer_id = %s;"
    cursor.execute(query (new_address, customer_id))
    cnx.commit()    #commit the transaction
    print("Query 5: Address updated successfully")

    '''
    Query 6: Increment the quantity of a specific item by 1
    '''
    item_id = 302
    query = "UPDATE Item SET quantity = quantity + 1 WHERE item_id = %s;"
    cursor.execute(query, (item_id,))
    cnx.commit()    #commit the transaction
    print("Query 6: Quantity updated successfully")

except mysql.connector.Error as err:
    print("Error", err)

    
'\n    Query 1: Show the details of a customer with a specific email address\n    '
Traceback (most recent call last):
  File "<pyshell#74>", line 7, in <module>
    cursor.execute(query, (email,))
AttributeError: 'function' object has no attribute 'execute'

=========================================================================================== RESTART: Shell ===========================================================================================
import datetime
import mysql.connector

cnx = mysql.connector.connect(user='root', password='SQL_Learner2024', host='localhost', database='AmazonWebPage')

cursor = cnx.cursor()

try:
    # Query 1: Retrieve customer information by email
    email = 'jerrycurls123@gmail.com'
    query = "SELECT * FROM Customer WHERE email = %s"
    cursor.execute(query, (email,))
    print("Query 1 Results:")
    for data in cursor:
        print(data)

    # Query 2: Retrieve items in a specific shopping cart
    cart_id = 202
    query = "SELECT * FROM Item WHERE cart_id = %s"
    cursor.execute(query, (cart_id,))
    print("\n Query 2 Results:")
    for data in cursor:
        print(data)

    # Query 3: Retrieve customer and product names for items in shopping carts
    query = """
    SELECT c.name AS customer_name, p.name AS product_name
    FROM ShoppingCart sc
    JOIN Customer c ON sc.customer_id = c.customer_id
    JOIN Item i ON sc.cart_id = i.cart_id
    JOIN Product p ON i.product_id = p.product_id
    """
    cursor.execute(query)
    print("\n Query 3 Results:")
    for data in cursor:
        print(data)

    # Query 4: Retrive product name, price, and quantity for a specific shopping cart
    cart_id = 202
    query = """
    SELECT p.name AS product_name, p.price, i.quantity
    FROM Item i
    JOIN Product p ON i.product_id = p.product_id
    WHERE i.cart_id = %s
    """
    cursor.execute(query, (cart_id,)
    print("\n Query 4 Results:")
    for data in cursor:
        print(data)

    # Query 5: Update customer address by customer ID
    new_address = '456 Elm St'
    customer_id = 2
    query = "UPDATE Customer SET address = %s WHERE customer_id = %s"
    cursor.execute(query, (new_address, customer_id))
    cnx.commit()
    print(f"\n Query 5: Address updated for customer ID {customer_id}")
                   
SyntaxError: '(' was never closed
try:
    # Query 1: Retrieve customer information by email
    email = 'jerrycurls123@gmail.com'
    query = "SELECT * FROM Customer WHERE email = %s"
    cursor.execute(query, (email,))
    print("Query 1 Results:")
    for data in cursor:
        print(data)

    # Query 2: Retrieve items in a specific shopping cart
    cart_id = 202
    query = "SELECT * FROM Item WHERE cart_id = %s"
    cursor.execute(query, (cart_id,))
    print("\n Query 2 Results:")
    for data in cursor:
...         print(data)
... 
...     # Query 3: Retrieve customer and product names for items in shopping carts
...     query = """
...     SELECT c.name AS customer_name, p.name AS product_name
...     FROM ShoppingCart sc
...     JOIN Customer c ON sc.customer_id = c.customer_id
...     JOIN Item i ON sc.cart_id = i.cart_id
...     JOIN Product p ON i.product_id = p.product_id
...     """
...     cursor.execute(query)
...     print("\n Query 3 Results:")
...     for data in cursor:
...         print(data)
... 
...     # Query 4: Retrive product name, price, and quantity for a specific shopping cart
...     cart_id = 202
...     query = """
...     SELECT p.name AS product_name, p.price, i.quantity
...     FROM Item i
...     JOIN Product p ON i.product_id = p.product_id
...     WHERE i.cart_id = %s
...     """
...     cursor.execute(query, (cart_id,))
...     print("\n Query 4 Results:")
...     for data in cursor:
...         print(data)
... 
...     # Query 5: Update customer address by customer ID
...     new_address = '456 Elm St'
...     customer_id = 2
...     query = "UPDATE Customer SET address = %s WHERE customer_id = %s"
...     cursor.execute(query, (new_address, customer_id))
...     cnx.commit()
...     print(f"\n Query 5: Address updated for customer ID {customer_id}")
... 
...     # Query 6: Update item quantity by item ID
...     new_quantity = 3
...     item_id = 302
...     query = "UPDATE Item SET quantity = %s WHERE item_id = %s"
...     cursor.execute(query, (new_quantity, item_id))
...     cnx.commit()
...     print(f"\n Query 6: Quantity updated for item ID {item_id}")
... 
... except mysql.connector.Error as err:
...     print("Error", err)
... 
...     
Query 1 Results:
(1, 'Jerry Curl', 'jerrycurls123@gmail.com', '123 Main St')

 Query 2 Results:
(302, 102, 202, 3)

 Query 3 Results:
('Jerry Curl', 'Game Console')
('Coopants Mudson', 'Desktop')

 Query 4 Results:
('Desktop', Decimal('1199.99'), 3)

 Query 5: Address updated for customer ID 2

 Query 6: Quantity updated for item ID 302
>>> cursor.close()
True
>>> cnx.close()
>>> 
cnx = mysql.connector.connect(user='root', password='SQL_Learner2024', host='localhost', database='AmazonWebPage')

cursor = cnx.cursor()

try:
    # Call the procedure GetAveragePrice
    cursor.callproc('GetAveragePrice')
    for result in cursor.stored_results():
        avg_price = result.fetchone()[0]
        print("Average Price of Products:", avg_price)

    # Call the function GetCustomerName
    customer_id = 1
    cursor.callproc('GetCustomerName', (customer_id,))
    customer_name = cursor.fetchone()[0]
    print("Customer Name:", customer_name)

except mysql.connector.Error as err:
    print("Error", err)

    
Error 1305 (42000): PROCEDURE amazonwebpage.GetAveragePrice does not exist
cnx = mysql.connector.connect(user='root', password='SQL_Learner2024', host='localhost', database='AmazonWebPage')
cursor = cnx.cursor()

try:
    # Call the procedure GetAveragePrice
    cursor.callproc('GetAveragePrice')
    for result in cursor.stored_results():
        avg_price = result.fetchone()[0]
        print("Average Price of Products:", avg_price)

    # Call the function GetCustomerName
    customer_id = 1
    cursor.callproc('GetCustomerName', (customer_id,))
    customer_name = cursor.fetchone()[0]
    print("Customer Name:", customer_name)

except mysql.connector.Error as err:
    print("Error", err)

    
()
Average Price of Products: 849.990000
Error 1305 (42000): PROCEDURE amazonwebpage.GetCustomerName does not exist
try:
    # Call the procedure GetAveragePrice
    cursor.callproc('GetAveragePrice')
    for result in cursor.stored_results():
        avg_price = result.fetchone()[0]
        print("Average Price of Products:", avg_price)

    # Call the function GetCustomerName
    customer_id = 1
    cursor.callproc('GetCustomerName', (customer_id,))
    customer_name = cursor.fetchone()[0]
    print("Customer Name:", customer_name)

except mysql.connector.Error as err:
    print("Error", err)

    
()
Average Price of Products: 849.990000
Error 1305 (42000): PROCEDURE amazonwebpage.GetCustomerName does not exist

try:
    # Call the procedure GetAveragePrice
    cursor.callproc('GetAveragePrice')
    for result in cursor.stored_results():
        avg_price = result.fetchone()[0]
        print("Average Price of Products:", avg_price)

    # Call the function GetCustomerName
    customer_id = 1
    cursor.execute("SELECT GetCustomerName(%s)", (customer_id,))
    customer_name = cursor.fetchone()[0]
    print("Customer Name: ", customer_name)

except mysql.connector.Error as err:
    print("Error", err)

    
()
Average Price of Products: 849.990000
Error 1172 (42000): Result consisted of more than one row

cnx = mysql.connector.connect(user='root', password='SQL_Learner2024', host='localhost', database='AmazonWebPage')
cursor = cnx.cursor()

try:
    # Call the procedure GetAveragePrice
    cursor.callproc('GetAveragePrice')
    for result in cursor.stored_results():
        avg_price = result.fetchone()[0]
        print("Average Price of Products:", avg_price)

    # Call the function GetCustomerName
    customer_id = 1
    cursor.execute("SELECT GetCustomerName(%s)", (customer_id,))
    customer_name = cursor.fetchone()[0]
    print("Customer Name: ", customer_name)

except mysql.connector.Error as err:
    print("Error", err)

    
()
Average Price of Products: 849.990000
Error 1172 (42000): Result consisted of more than one row
try:
    # Call the procedure GetAveragePrice
    cursor.callproc('GetAveragePrice')
    for result in cursor.stored_results():
        avg_price = result.fetchone()[0]
        print("Average Price of Products:", avg_price)

    except mysql.connector.Error as err:
        
SyntaxError: invalid syntax
try:
    # Call the procedure GetAveragePrice
    cursor.callproc('GetAveragePrice')
    for result in cursor.stored_results():
        avg_price = result.fetchone()[0]
        print("Average Price of Products:", avg_price)

except mysql.connector.Error as err:
    print("Error:", err)

    
()
Average Price of Products: 849.990000

try:
    # Call the function GetCustomerName
    cursor.execute("SELECT GetCustomerName(1)")
    customer_name = cursor.fetchone()[0]
    print("Customer Name:", customer_name)

except mysql.connector.Error as err:
    print("Error", err)

    
Error 1172 (42000): Result consisted of more than one row

cnx = mysql.connector.connect(user='root', password='SQL_Learner2024', host='localhost', database='AmazonWebPage')
cursor = cnx.cursor()

